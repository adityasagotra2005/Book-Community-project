const express = require("express");
const router = express.Router();

const reviewController = require("../controllers/reviewController");
const { isLoggedIn } = require("../middleware/authMiddleware");

// Show Book Detail
router.get("/book/:id",
    isLoggedIn,
    reviewController.showBookDetail
);

// Add Review
router.post("/book/:id/review",
    isLoggedIn,
    reviewController.addReview
);

// Edit Review Page
router.get("/review/edit/:id",
    isLoggedIn,
    reviewController.showEditReview
);

// Update Review
router.post("/review/update/:id",
    isLoggedIn,
    reviewController.updateReview
);

// Delete Review
router.get("/review/delete/:id",
    isLoggedIn,
    reviewController.deleteReview
);

module.exports = router;