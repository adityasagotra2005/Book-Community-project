const express = require("express");
const router = express.Router();
const bookController = require("../controllers/bookController");
const discussionController=require("../controllers/discussionController");
const { isLoggedIn } = require("../middleware/authMiddleware");
const upload = require("../config/multer");
router.get("/add-book", isLoggedIn, bookController.showAddBook);
router.post("/add-book", isLoggedIn,upload.single("image"), bookController.addBook);

router.get("/books", isLoggedIn, bookController.getAllBooks);
router.get("/edit-book/:id", isLoggedIn, bookController.showEditBook);
router.post("/edit-book/:id", isLoggedIn, bookController.updateBook);
router.get("/my-books", isLoggedIn, bookController.getMyBooks);
router.get("/delete-book/:id", isLoggedIn, bookController.deleteBook);
router.get("/book/:id", isLoggedIn, bookController.bookDetail);
router.post("/favorite/:id", isLoggedIn, bookController.addFavorite);

router.post("/favorite/remove/:id", isLoggedIn, bookController.removeFavorite);

router.get("/my-favorites", isLoggedIn, bookController.myFavorites);
router.post("/discussion/:bookId",isLoggedIn,discussionController.addDiscussion);
module.exports = router;