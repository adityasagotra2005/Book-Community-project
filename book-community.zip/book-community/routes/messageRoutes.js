const express = require("express");
const router = express.Router();

const messageController = require("../controllers/messageController");
const {isLoggedIn} = require("../middleware/authMiddleware");

router.get("/chat/:userId",isLoggedIn,messageController.chatPage);

router.post("/chat/:userId",isLoggedIn,messageController.sendMessage);

module.exports = router;