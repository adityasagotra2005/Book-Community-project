const express = require("express");
const router = express.Router();
const upload = require("../config/multer");
const userController = require("../controllers/userController");
const { isLoggedIn } = require('../middleware/authMiddleware');
router.get("/register", userController.showRegister);
router.post("/register", userController.registerUser);

router.get("/login", userController.showLogin);
router.post("/login", userController.loginUser);
router.get("/logout", userController.logoutUser);
router.get("/leaderboard", isLoggedIn, userController.leaderboard);
router.get("/profile/:id", isLoggedIn, userController.profilePage);

router.post("/follow/:id", isLoggedIn, userController.followUser);

router.post("/unfollow/:id", isLoggedIn, userController.unfollowUser);
router.post("/update-profile", isLoggedIn, userController.updateProfile);
router.post("/update-photo",
isLoggedIn,
upload.single("photo"),
userController.updatePhoto);
module.exports = router;