const express = require("express");
const router = express.Router();

const feedController = require("../controllers/feedController");
const { isLoggedIn } = require("../middleware/authMiddleware");

router.get("/feed",isLoggedIn,feedController.getFeed);

module.exports = router;