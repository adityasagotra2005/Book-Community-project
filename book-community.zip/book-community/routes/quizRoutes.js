const express = require("express");
const router = express.Router();
const quizController = require("../controllers/quizController");
const { isLoggedIn,isAdmin } = require("../middleware/authMiddleware");

// ADMIN
router.get("/admin/create-quiz", isLoggedIn, isAdmin, quizController.createQuizPage);
router.post("/admin/create-quiz", isLoggedIn, isAdmin, quizController.createQuiz);

router.get("/admin/quiz/:id/questions", isLoggedIn, isAdmin, quizController.addQuestionPage);
router.post("/admin/quiz/:id/questions", isLoggedIn, isAdmin, quizController.addQuestion);
router.post("/admin/quiz/:id/finish", isLoggedIn, isAdmin, quizController.finishQuiz);
router.get("/admin/quizzes", isLoggedIn, isAdmin, quizController.adminQuizList);
// USER
router.get("/quiz", isLoggedIn, quizController.showQuiz);
router.post("/quiz/:id/submit", isLoggedIn, quizController.submitQuiz);
router.get("/quiz-leaderboard", quizController.leaderboard);

module.exports = router;