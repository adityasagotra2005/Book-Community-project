const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
    quiz: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Quiz"
    },
    questionText: String,
    options: [String],
    correctAnswer: Number,
    marks: { type: Number, default: 1 }
});

module.exports = mongoose.model("Question", questionSchema);