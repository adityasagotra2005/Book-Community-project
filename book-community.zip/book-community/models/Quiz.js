const mongoose = require("mongoose");

const quizSchema = new mongoose.Schema({
    title: String,
    month: String,
    duration: Number,
    isActive: { type: Boolean, default: false },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    isPublished: {
    type: Boolean,
    default: false
}
}, { timestamps: true });

module.exports = mongoose.model("Quiz", quizSchema);