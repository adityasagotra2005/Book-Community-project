const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true },
    password: String,

    points: {
        type: Number,
        default: 0
    },

    streak: {
        type: Number,
        default: 0
    },

    maxStreak: {
        type: Number,
        default: 0
    },

    lastActiveDate: {
        type: Date
    },

    role: {
        type: String,
        enum: ["user", "admin"],
        default: "user"
    },

    favorites:[{
type: mongoose.Schema.Types.ObjectId,
ref: "Book"
}],

bio:{
type:String,
default:""
},

profileImage:{
type:String,
default:"default.png"
},

followers:[{
type:mongoose.Schema.Types.ObjectId,
ref:"User"
}],

following:[{
type:mongoose.Schema.Types.ObjectId,
ref:"User"
}]

});

module.exports = mongoose.model("User", userSchema);