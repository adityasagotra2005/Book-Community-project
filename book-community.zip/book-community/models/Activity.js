const mongoose = require("mongoose");

const activitySchema = new mongoose.Schema({

user:{
type:mongoose.Schema.Types.ObjectId,
ref:"User"
},

type:{
type:String,
enum:["add_book","review","follow"]
},

book:{
type:mongoose.Schema.Types.ObjectId,
ref:"Book"
},

targetUser:{
type:mongoose.Schema.Types.ObjectId,
ref:"User"
},

createdAt:{
type:Date,
default:Date.now
}

});

module.exports = mongoose.model("Activity",activitySchema);