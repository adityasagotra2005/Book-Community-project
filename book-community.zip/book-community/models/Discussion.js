const mongoose = require("mongoose");

const discussionSchema = new mongoose.Schema({

book:{
type:mongoose.Schema.Types.ObjectId,
ref:"Book",
required:true
},

user:{
type:mongoose.Schema.Types.ObjectId,
ref:"User",
required:true
},

message:{
type:String,
required:true
}

},{timestamps:true});

module.exports = mongoose.model("Discussion",discussionSchema);