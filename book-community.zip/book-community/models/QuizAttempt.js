const mongoose = require("mongoose");

const attemptSchema = new mongoose.Schema({
    quiz: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Quiz"
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    score: Number,
    totalMarks: Number,
    submittedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("QuizAttempt", attemptSchema);