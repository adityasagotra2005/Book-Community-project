exports.updateStreak = (user) => {
    const today = new Date();
    const last = user.lastActiveDate;

    if (!last) {
        user.streak = 1;
    } else {
        const diff = Math.floor(
            (today - last) / (1000 * 60 * 60 * 24)
        );

        if (diff === 1) {
            user.streak += 1;
        } else if (diff > 1) {
            user.streak = 1;
        }
    }

    if (user.streak > user.maxStreak) {
        user.maxStreak = user.streak;
    }

    user.lastActiveDate = today;
};