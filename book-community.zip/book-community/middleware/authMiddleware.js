const jwt = require("jsonwebtoken");

exports.isLoggedIn = (req, res, next) => {
    const token = req.cookies.token;

    if (!token) {
        return res.redirect("/login");
    }

    try {
        const decoded = jwt.verify(token, "secretkey");
        req.user = decoded;   // includes userId, name, role
        res.locals.currentUser = decoded;
        next();
    } catch (err) {
        return res.redirect("/login");
    }
};
exports.isAdmin = (req, res, next) => {

    if (!req.user || req.user.role !== "admin") {
        return res.status(403).send("Access Denied  Admin Only");
    }

    next();
};