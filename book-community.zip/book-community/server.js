const express = require("express");
const mongoose = require("mongoose");
const http = require("http");
const { Server } = require("socket.io");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const User = require("./models/User");
const Book = require("./models/Book");
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const userRoutes = require("./routes/userRoutes");
const bookRoutes = require("./routes/bookRoutes");
const reviewRoutes = require("./routes/reviewRoutes");
const quizRoutes = require("./routes/quizRoutes");
const { isLoggedIn } = require("./middleware/authMiddleware");
const feedRoutes = require("./routes/feedRoutes");
const Message = require("./models/Message");
// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.set("view engine", "ejs");
app.use(express.static("public"));

// MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/bookcommunity")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));
app.use((req, res, next) => {
    res.locals.currentUser = null;

    const token = req.cookies.token;
    if (token) {
        try {
            const jwt = require("jsonwebtoken");
            const decoded = jwt.verify(token, "secretkey");
            res.locals.currentUser = decoded;
        } catch (err) {
            res.locals.currentUser = null;
        }
    }

    next();
});
// Home Route
app.get("/", (req, res) => {
    res.render("index");
});

const messageRoutes = require("./routes/messageRoutes");
app.use("/",messageRoutes);
app.use("/", userRoutes);
app.use("/", reviewRoutes);
app.use("/", quizRoutes);
app.use("/",feedRoutes);
app.get("/dashboard", isLoggedIn, async (req, res) => {

    const user = await User.findById(req.user.userId);

    const totalBooks = await Book.countDocuments();
    const myBooks = await Book.countDocuments({ addedBy: user._id });

    const topBooks = await Book.find()
        .sort({ averageRating: -1 })
        .limit(6)
        .populate("addedBy");

    res.render("dashboard", {
        user,
        totalBooks,
        myBooks,
        topBooks
    });
});
app.use("/", bookRoutes);
/* SOCKET.IO*/
io.on("connection",(socket)=>{

console.log("User connected:",socket.id);

socket.on("joinRoom",(userId)=>{
socket.join(userId);
});

socket.on("sendMessage",async(data)=>{

/* SAVE MESSAGE IN DATABASE */

await Message.create({
sender:data.senderId,
receiver:data.receiverId,
message:data.message
});

/* SEND MESSAGE TO RECEIVER */

io.to(data.receiverId).emit("receiveMessage",data);

});

socket.on("disconnect",()=>{
console.log("User disconnected");
});

});
server.listen(5000,()=>{
console.log("Server running on port 5000");
});