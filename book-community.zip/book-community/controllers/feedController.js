const Activity = require("../models/Activity");

exports.getFeed = async (req,res)=>{

const activities = await Activity.find()
.populate("user")
.populate("book")
.populate("targetUser")
.sort({createdAt:-1})
.limit(20);

res.render("feed",{activities});

};