const Book = require("../models/Book");
const User = require("../models/User");
const Review = require("../models/Review");
const { updateStreak } = require("../utils/streak");
const Discussion = require("../models/Discussion");
const Activity = require("../models/Activity");
// Show Add Book Page
exports.showAddBook = (req, res) => {
    res.render("addBook");
};

// Add Book
exports.addBook = async (req, res) => {
    try {
        const { title, author, description } = req.body;
          const user = await User.findById(req.user.userId);
        await Book.create({
            title,
            author,
            description,
            image: req.file ? req.file.filename : null,
            addedBy: req.user.userId
        });
       
     await Activity.create({
user:req.user.userId,
type:"add_book"
});
             user.points += 10; 
             updateStreak(user);

await user.save();

       res.redirect("/my-books");

    } catch (err) {
        res.send(err.message);
    }
};

// Show All Books
exports.getAllBooks = async (req, res) => {
    try {

        const books = await Book.find({
            addedBy: { $ne: req.user.userId }   // exclude own books
        }).populate("addedBy");

        res.render("books", {
    books,
    currentUser: req.user
});

    } catch (err) {
        res.send(err.message);
    }
};
// Show Edit Page
exports.showEditBook = async (req, res) => {
    const book = await Book.findById(req.params.id);
    res.render("editBook", { book });
};

// Update Book
exports.updateBook = async (req, res) => {
    const { title, author, description } = req.body;

    await Book.findByIdAndUpdate(req.params.id, {
        title,
        author,
        description
    });

   res.redirect("/my-books");
};

// Delete Book
exports.deleteBook = async (req, res) => {
    try {
        const bookId = req.params.id;

        await Review.deleteMany({ book: bookId });

        await Book.findByIdAndDelete(bookId);

        res.redirect("/my-books");

    } catch (err) {
        res.send(err.message);
    }
};
// Show Only Logged-in User Books
exports.getMyBooks = async (req, res) => {
    const books = await Book.find({ addedBy: req.user.userId });
    res.render("myBooks", { books });
};
exports.addFavorite = async (req, res) => {

const user = await User.findById(req.user.userId);

if (!user.favorites.includes(req.params.id)) {
    user.favorites.push(req.params.id);
}

await user.save();

res.redirect("/books");
};


// Remove favorite
exports.removeFavorite = async (req, res) => {

await User.findByIdAndUpdate(req.user.userId,{
    $pull:{ favorites:req.params.id }
});

res.redirect("/my-favorites");

};


// Show favorites page
exports.myFavorites = async (req, res) => {

const user = await User.findById(req.user.userId)
.populate("favorites");

res.render("books/myFavorites",{
    books:user.favorites
});

};
// Show Book Detail
exports.bookDetail = async (req, res) => {

try{

const book = await Book.findById(req.params.id)
.populate("addedBy");

const reviews = await Review.find({book:req.params.id})
.populate("user")
.sort({createdAt:-1});

const discussions = await Discussion.find({book:req.params.id})
.populate("user")
.sort({createdAt:-1});


// Save Recently Viewed Book
await User.findByIdAndUpdate(
    req.user.userId,
    { $addToSet:{ recentlyViewed:book._id } }
);

const user = await User.findById(req.user.userId)
.populate("recentlyViewed");

const averageRating =
reviews.length > 0
? reviews.reduce((sum,r)=>sum+r.rating,0)/reviews.length
:0;

res.render("bookDetail",{
book,
reviews,
discussions,
averageRating:averageRating.toFixed(1),
totalReviews:reviews.length,
currentUser:req.user
});

}catch(err){

console.log(err);
res.send("Error loading book");

}

};