const Review = require("../models/Review");
const Book = require("../models/Book");
const Discussion = require("../models/Discussion");
const Activity = require("../models/Activity");
// 🔥 SHOW BOOK DETAIL PAGE
exports.showBookDetail = async (req, res) => {
    try {

        const book = await Book.findById(req.params.id)
            .populate("addedBy");

        const reviews = await Review.find({ book: req.params.id })
            .populate("user")
            .sort({ createdAt: -1 });
           const discussions = await Discussion.find({ book: req.params.id })
.populate("user")
.sort({ createdAt: -1 });
        //  Calculate Average (NUMBER not string)
        let averageRating = 0;

        if (reviews.length > 0) {
            const total = reviews.reduce((sum, r) => sum + r.rating, 0);
            averageRating = total / reviews.length;
        }

        res.render("bookDetail", {
            book,
            reviews,
            discussions,
            currentUser: req.user,
            averageRating,
            totalReviews: reviews.length
        });

    } catch (err) {
        res.send(err.message);
    }
};


// 🔥 ADD REVIEW
exports.addReview = async (req, res) => {
    try {
console.log(req.user);
        if (!req.user || !req.user.userId) {
    return res.send("User not authenticated properly");
}

        const { comment, rating } = req.body;

       await Review.create({
    comment,
    rating: Number(rating),
    user: req.user.userId,   
    book: req.params.id
});
await Activity.create({
user:req.user.userId,
type:"review",
book:req.params.id
});
        res.redirect("/book/" + req.params.id);

    } catch (err) {
        res.send(err.message);
    }
};

// 🔥 SHOW EDIT REVIEW PAGE
exports.showEditReview = async (req, res) => {

    const review = await Review.findById(req.params.id);

    if (!review) return res.send("Review not found");

    // Ownership check
    if (review.user.toString() !== req.user.userId) {
    return res.send("Not authorized");
}
    res.render("editReview", { review });
};


// 🔥 UPDATE REVIEW
exports.updateReview = async (req, res) => {

    const review = await Review.findById(req.params.id);

    if (!review) return res.send("Review not found");


    review.comment = req.body.comment;
    review.rating = Number(req.body.rating);

    await review.save();

    res.redirect("/book/" + review.book);
};


// 🔥 DELETE REVIEW
exports.deleteReview = async (req, res) => {

    const review = await Review.findById(req.params.id);

    if (!review) return res.send("Review not found");


    const bookId = review.book;

    await Review.findByIdAndDelete(req.params.id);

    res.redirect("/book/" + bookId);
};