const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
// Show Register Page
exports.showRegister = (req, res) => {
    res.render("register");
};

// Handle Register
exports.registerUser = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.send("User already exists");
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        await User.create({
            name,
            email,
            password: hashedPassword
        });

        res.redirect("/login");

    } catch (err) {
        res.send(err.message);
    }
};
// Show Login Page
exports.showLogin = (req, res) => {
    res.render("login");
};

// Handle Login
exports.loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });
         console.log("Found User:", user);
        if (!user) {
            return res.send("User not found");
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.send("Invalid credentials");
        }

        const token = jwt.sign(
            { userId: user._id,
                name: user.name,
                 role: user.role
             },
            "secretkey",
            { expiresIn: "1h" }
        );

        res.cookie("token", token);
        res.redirect("/dashboard");

    } catch (err) {
        res.send(err.message);
    }
};
exports.logoutUser = (req, res) => {
    res.clearCookie("token");
    res.redirect("/login");
};
exports.leaderboard = async (req, res) => {
    const users = await User.find().sort({ points: -1 });
    res.render("leaderboard", { users });
};
const Book = require("../models/Book");

exports.profilePage = async (req,res)=>{

const user = await User.findById(req.params.id)
.populate("followers","name")
.populate("following","name");

const books = await Book.find({
addedBy:req.params.id
});

res.render("profile",{
profileUser:user,
books,
currentUser:req.user
});

};
exports.followUser = async(req,res)=>{

const currentUserId = req.user.userId;
const targetUserId = req.params.id;

if(currentUserId == targetUserId){
return res.redirect("/profile/"+targetUserId);
}

const currentUser = await User.findById(currentUserId);
const targetUser = await User.findById(targetUserId);

if(!targetUser.followers.includes(currentUserId)){

targetUser.followers.push(currentUserId);
currentUser.following.push(targetUserId);

await targetUser.save();
await currentUser.save();

}

res.redirect("/profile/"+targetUserId);

};
exports.unfollowUser = async(req,res)=>{

const currentUserId = req.user.userId;
const targetUserId = req.params.id;

const currentUser = await User.findById(currentUserId);
const targetUser = await User.findById(targetUserId);

targetUser.followers.pull(currentUserId);
currentUser.following.pull(targetUserId);

await targetUser.save();
await currentUser.save();

res.redirect("/profile/"+targetUserId);

};
exports.updateProfile = async(req,res)=>{

await User.findByIdAndUpdate(
req.user.userId,
{
bio:req.body.bio
});

res.redirect("/profile/"+req.user.userId);

};
exports.updatePhoto = async(req,res)=>{

await User.findByIdAndUpdate(
req.user.userId,
{
profileImage:req.file.filename
}
);

res.redirect("/profile/"+req.user.userId);

};