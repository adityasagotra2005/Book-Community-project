const Message = require("../models/Message");
const User = require("../models/User");

exports.chatPage = async(req,res)=>{

const receiverId = req.params.userId;

const receiver = await User.findById(receiverId);

const messages = await Message.find({
$or:[
{sender:req.user.userId,receiver:receiverId},
{sender:receiverId,receiver:req.user.userId}
]
})
.populate("sender")
.sort({createdAt:1});

res.render("chat",{
messages,
receiver,
currentUser:req.user
});

};


exports.sendMessage = async(req,res)=>{

const receiverId = req.params.userId;

await Message.create({

sender:req.user.userId,
receiver:receiverId,
message:req.body.message

});

res.redirect("/chat/"+receiverId);

};