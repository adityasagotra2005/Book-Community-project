const Quiz = require("../models/Quiz");
const Question = require("../models/Question");
const QuizAttempt = require("../models/QuizAttempt");
const User = require("../models/User");


// ================= ADMIN =================

// Create Quiz Page
exports.createQuizPage = (req, res) => {
    res.render("admin/createQuiz");
};

// Save Quiz
exports.createQuiz = async (req, res) => {
    const { title, month, duration } = req.body;

    const quiz = await Quiz.create({
        title,
        month,
        duration,
        createdBy: req.user.userId
    });

    res.redirect(`/admin/quiz/${quiz._id}/questions`);
};

// Add Question Page
exports.addQuestionPage = async (req, res) => {
    try {
        const questions = await Question.find({ quiz: req.params.id });

        res.render("admin/addQuestions", {
            quizId: req.params.id,
            questions
        });

    } catch (err) {
        res.send("Error loading questions");
    }
};

// Save Question
exports.addQuestion = async (req, res) => {
    try {
        const { questionText, option1, option2, option3, option4, correctAnswer, marks } = req.body;

        await Question.create({
            quiz: req.params.id,
            questionText,
            options: [option1, option2, option3, option4],
            correctAnswer: Number(correctAnswer),
            marks: Number(marks)
        });

        // Redirect back to same quiz question page
        res.redirect(`/admin/quiz/${req.params.id}/questions`);

    } catch (err) {
        console.log(err);
        res.send("Error adding question");
    }
};

exports.finishQuiz = async (req, res) => {
    try {
        await Quiz.findByIdAndUpdate(req.params.id, {
            isPublished: true
        });

        res.redirect("/admin/quizzes"); // change if needed

    } catch (err) {
        res.send("Error finishing quiz");
    }
};exports.adminQuizList = async (req, res) => {
    try {
        const quizzes = await Quiz.find().sort({ createdAt: -1 });

        res.render("admin/quizList", { quizzes });

    } catch (err) {
        res.send("Error loading quizzes");
    }
};
// ================= USER =================

// Show Active Quiz
exports.showQuiz = async (req, res) => {

    const quiz = await Quiz.findOne({
        isPublished: true
    }).sort({ createdAt: -1 });

    if (!quiz) return res.send("No active quiz");

    // CHECK IF USER ALREADY ATTEMPTED
    const existingAttempt = await QuizAttempt.findOne({
        quiz: quiz._id,
        user: req.user.userId
    });

    if (existingAttempt) {
        return res.render("quiz/alreadyAttempted");
    }

    const questions = await Question.find({ quiz: quiz._id });

    res.render("quiz/attemptQuiz", { quiz, questions });
};
// Submit Quiz
exports.submitQuiz = async (req, res) => {

    // Check again before saving
    const existingAttempt = await QuizAttempt.findOne({
        quiz: req.params.id,
        user: req.user.userId
    });

    if (existingAttempt) {
       return res.render("quiz/alreadyAttempted");
    }

    const questions = await Question.find({ quiz: req.params.id });

    let score = 0;

    questions.forEach(q => {
        const selected = parseInt(req.body[q._id]);

        if (selected === q.correctAnswer) {
            score += q.marks;
        }
    });

    const totalMarks = questions.reduce((sum, q) => sum + q.marks, 0);

    await QuizAttempt.create({
        quiz: req.params.id,
        user: req.user.userId,
        score,
        totalMarks
    });

    await User.findByIdAndUpdate(req.user.userId, {
        $inc: { points: score }
    });

    res.render("quiz/result", { score, totalMarks });
};

// Leaderboard
exports.leaderboard = async (req, res) => {

    try {

        // Get latest published quiz
        const quiz = await Quiz.findOne({
            isPublished: true
        }).sort({ createdAt: -1 });

        if (!quiz) {
            return res.send("No quiz available");
        }

        // Get attempts only for this quiz
        const attempts = await QuizAttempt.find({
            quiz: quiz._id
        })
        .sort({ score: -1 }) // highest score first
        .populate("user");

        res.render("quiz/leaderboard", {
            attempts,
            quiz
        });

    } catch (err) {
        res.send("Error loading leaderboard");
    }
};