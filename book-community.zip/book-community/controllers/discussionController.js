const Discussion = require("../models/Discussion");

exports.addDiscussion = async(req,res)=>{

await Discussion.create({
book:req.params.bookId,
user:req.user.userId,
message:req.body.message
});

res.redirect(`/book/${req.params.bookId}`);

};

exports.getDiscussions = async(bookId)=>{

return await Discussion.find({book:bookId})
.populate("user")
.sort({createdAt:-1});

};